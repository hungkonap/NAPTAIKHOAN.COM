# NAPTAIKHOAN.COM — Android 9.2.5 (TWA)

## Có gì trong bộ này?
- Dự án Android chạy trực tiếp https://naptaikhoan.com/ bằng Trusted Web Activity (không dùng WebView nhúng).
- Mở website dưới biểu tượng ứng dụng NAPTAIKHOAN.COM, dùng backend PHP / MySQL sẵn có.
- Chỉ xin quyền INTERNET. Không nhúng API Key hay tài khoản ngân hàng vào APK.
- Dự án GitHub Actions để tạo APK TEST hoặc APK chính thức đã ký; khi dùng API bên ngoài, việc chuyển sang trình duyệt bên ngoài có thể là hành vi bình thường.

## A. Tạo APK TEST để thử ngay (không cần khóa ký)
1. Đưa **nội dung** thư mục dự án Android lên một repository GitHub riêng (không đẩy source PHP, mật khẩu hoặc SQL lên đó).
2. Mở tab **Actions**, chọn **Build Android TEST APK** → **Run workflow**.
3. Tải artifact `NAPTAIKHOAN-TEST-APK` từ lần chạy thành công, giải nén, cài `NAPTAIKHOAN-TEST.apk` lên Android.
4. Nếu muốn app mở toàn màn hình, đưa `assetlinks.json` trong cùng artifact vào đường dẫn `https://naptaikhoan.com/.well-known/assetlinks.json` và cần hoàn tất cấu hình PWA trên hosting trước.
5. Test APK không dùng để bán/phát hành cho khách; khi chuyển qua release, sẽ có chữ ký mới, cần cập nhật lại `assetlinks.json`.

## B. Tạo khóa ký chính thức và lưu an toàn
Tạo khóa ký bằng JDK keytool trên máy **do bạn kiểm soát** (không chia sẻ file .jks hay mật khẩu):

`keytool -genkeypair -v -keystore ntk-release.jks -storetype PKCS12 -keyalg RSA -keysize 3072 -validity 10000 -alias ntk-release`

Hãy cất bản sao ngoại tuyến của `ntk-release.jks` cùng mật khẩu ở nơi an toàn. Mất khóa ký sẽ gây khó khăn cho các bản APK cập nhật sau này.

Trong GitHub repository → Settings → Secrets and variables → Actions, tạo 4 secrets:
- `NTK_KEYSTORE_BASE64`: nội dung base64 của toàn bộ file ntk-release.jks (không phải đường dẫn).
- `NTK_KEYSTORE_PASSWORD`: mật khẩu keystore.
- `NTK_KEY_ALIAS`: ntk-release (hoặc alias đã tạo).
- `NTK_KEY_PASSWORD`: mật khẩu của khóa.

Gợi ý cách đổi file keystore sang base64 không xuống dòng:
- PowerShell (Windows): `[Convert]::ToBase64String([IO.File]::ReadAllBytes('C:\duong-dan\ntk-release.jks'))`
- macOS: `base64 < ntk-release.jks | tr -d '\n'`
- Linux: `base64 -w 0 ntk-release.jks`

Đừng gửi secrets qua chat, đừng thêm chúng vào ZIP/repository.

## C. Tạo APK RELEASE chính thức
1. Vào GitHub → Actions → **Build signed Android release APK** → **Run workflow**.
2. Tải artifact `NAPTAIKHOAN-signed-release-9.2.5` có: `NAPTAIKHOAN-9.2.5.apk` (đã ký); `assetlinks.json` (theo chính chứng chỉ trong APK); kết quả kiểm tra chữ ký và SHA256 file APK.
3. Trên cPanel → File Manager, upload `assetlinks.json` đúng đường dẫn `public_html/.well-known/assetlinks.json` của naptaikhoan.com. Không thay thế một `assetlinks.json` đang phục vụ ứng dụng khác nếu chưa hiểu nội dung hiện tại: cần gộp các statements.
4. Kiểm tra đường dẫn `https://naptaikhoan.com/.well-known/assetlinks.json` trả HTTPS 200, kiểu `application/json`, và KHÔNG redirect. Kiểm tra `https://naptaikhoan.com/manifest.webmanifest` trả JSON và icon hoạt động.
5. Cài thử APK trên điện thoại Android: xem có thanh địa chỉ không; thử đăng nhập, Google OAuth, đổi thẻ, mua thẻ, nạp tiền, quay lại từ cổng thanh toán, link hỗ trợ, và trạng thái đơn pending.
6. Chỉ khi toàn bộ thử nghiệm ổn mới đăng APK lên website cho khách tải. Nên phát hành với tên file và SHA256 hiển thị rõ ràng.

## D. Cập nhật website PWA
ZIP `naptaikhoan_pwa_9.2.5_hoan_thien.zip` được dùng để upload đè đúng các file tương ứng trong document root của naptaikhoan.com: header mới/cũ, `.htaccess` (kiểm tra cẩn thận nếu đã sửa thêm), `manifest.webmanifest`, `sw.js`, `pwa/offline.html`, và các icon. Sao lưu trước khi upload.

Cảnh báo: nếu naptaikhoan.com và gachthe24s.com cùng dùng chung source, code header chỉ đăng ký PWA cho naptaikhoan.com. Không tự động đổi thương hiệu gachthe24s.com.

## E. Điều kiện và hạn chế
- **Không có APK đã biên dịch trong ZIP này**. Môi trường chuẩn bị dự án không có Android SDK/Gradle và không thể tải SDK. Dùng GitHub Actions hoặc Android Studio để biên dịch.
- Việc không hiện thanh địa chỉ chỉ được bảo đảm sau khi APK đã ký và Digital Asset Links hợp lệ trên hosting.
- Cần có trình duyệt Android hỗ trợ TWA; nếu không sẽ mở theo chế độ browser/Custom Tab.
- Các website bên ngoài (đăng nhập Google, ngân hàng, liên hệ Zalo) có thể mở ra trình duyệt khác, bình thường.
- Sửa nội dung PHP không bắt buộc đổi APK; sửa package, manifest, icon hoặc mã Android thì phải build APK mới. Cần tăng versionCode khi phát hành cập nhật.
- Chưa thể kiểm thử đăng nhập hoặc thanh toán thực tế trên hosting khi chưa được phép triển khai và có điện thoại thử nghiệm.
