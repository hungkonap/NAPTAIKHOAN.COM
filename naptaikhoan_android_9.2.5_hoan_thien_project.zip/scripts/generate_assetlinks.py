#!/usr/bin/env python3
"""Create Digital Asset Links for the *actual app signing certificate*.

Usage:
  python3 scripts/generate_assetlinks.py 'AB:CD:...:EF'
  python3 scripts/generate_assetlinks.py '<64 hex SHA256 characters>'
Writes assetlinks.json in current directory. Upload it to
https://naptaikhoan.com/.well-known/assetlinks.json without a redirect.
"""
import json, re, sys
from pathlib import Path

if len(sys.argv) != 2:
    raise SystemExit('Expected SHA-256 certificate fingerprint argument')
raw = sys.argv[1].strip().replace(':', '').replace(' ', '')
if not re.fullmatch(r'[0-9a-fA-F]{64}', raw):
    raise SystemExit('Expected SHA256 digest: exactly 64 hexadecimal digits')
sha = ':'.join(raw[i:i+2] for i in range(0, 64, 2)).upper()
statement = [{
    'relation': ['delegate_permission/common.handle_all_urls'],
    'target': {
        'namespace': 'android_app',
        'package_name': 'com.naptaikhoan.app',
        'sha256_cert_fingerprints': [sha]
    }
}]
Path('assetlinks.json').write_text(json.dumps(statement, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('Digital Asset Links ready: com.naptaikhoan.app / SHA-256 ' + sha)
